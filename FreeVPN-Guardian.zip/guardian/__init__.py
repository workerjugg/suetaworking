"""FreeVPN Guardian core."""
